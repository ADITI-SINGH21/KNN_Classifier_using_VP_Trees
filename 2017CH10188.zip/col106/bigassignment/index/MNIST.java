package col106.bigassignment.index;
public interface MNIST{
	public int[] getImage();
	public int getLabel();
	public int getIndexFromTrainingSet();
}